export interface Productinfo {
    product_id:number;
    p_name:string;
    description:string;
    price:number;
    available:string;
    free_delivery:string;
    category:string;

}