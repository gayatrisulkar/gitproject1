package com.onlinefooddelivery;


import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.onlinefooddelivery.dao.ALoginRepository;
import com.onlinefooddelivery.dao.OrderRepository;
import com.onlinefooddelivery.dao.ProductRepository;
import com.onlinefooddelivery.dao.RegisterRepository;
import com.onlinefooddelivery.model.ALogin;
import com.onlinefooddelivery.model.Register;
@SpringBootTest
class SpringbackendApplicationTests {
	@Autowired      
	RegisterRepository registerRepository;
	@Autowired
	ProductRepository productRepository;
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	ALoginRepository aloginRepository;
	
	@Test
	public void addRegisters() {
		Register registers = new Register();
		
		registers.setF_name("t");
		registers.setL_name("u");
		registers.setAddress("mumbai");
		registers.setEmail_id("t@gmail.com");
		registers.setPhone_no(9.657458418);
		registers.setPassword("6476145");
		registerRepository.save(registers);
		assertNotNull(registerRepository.findById(2).get());
	}

	@Test
	public void AllRegisters() {
		List<Register> list = registerRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void Register() {
		Register registers = registerRepository.findById(1).get();
		assertEquals(1, registers.getUser_id());
	}

	@Test
	public void addProduct() {
		com.onlinefooddelivery.model.Product product=new com.onlinefooddelivery.model.Product();
		product.setProduct_id(4);
		product.setP_name("m");
		product.setDescription("k");
		product.setPrice(2);
		product.setAvailable("jdha");
		product.setFree_delivery("yes");
		product.setCategory("indian");
		
		productRepository.save(product);
		assertNotNull(productRepository.findById(4).get());

	}
	@Test
	public void AllProduct() {
		List<com.onlinefooddelivery.model.Product> list=productRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void Product() {
		com.onlinefooddelivery.model.Product product = productRepository.findById(1).get();
		assertEquals(1,product.getProduct_id());
	}
	
	@Test
	public void addOrder() {
		com.onlinefooddelivery.model.Order order=new com.onlinefooddelivery.model.Order();
		order.setOrder_id(2);
		order.setAddress("m");
		order.setQuantity("3");
		order.setTrack_no(2);
		order.setUpi_id("jdha");
		orderRepository.save(order);
		assertNotNull(productRepository.findById(2).get());

	}
	@Test
	public void AllOrder() {
		List<com.onlinefooddelivery.model.Order> list=orderRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void Order() {
		com.onlinefooddelivery.model.Order order = orderRepository.findById(1).get();
		assertEquals(1,order.getOrder_id());
	}
	


	@Test
	public void AllALogin() {
		List<com.onlinefooddelivery.model.ALogin> list=aloginRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void ALogin() {
		com.onlinefooddelivery.model.ALogin alogin = aloginRepository.findById("a@gmail.com").get();
		assertEquals("a@gmail.com",alogin.getEmail_id());
	}
	
}