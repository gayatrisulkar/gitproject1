export class Product {
    product_id:number=0;
    p_name:string="";
    description:string="";
    price:number=0;
    available:string="";
    free_delivery:string="";
    category:string="";
    url:string="";

}