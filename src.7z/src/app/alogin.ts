

export class ALogin {
    
    email_id:string="";
    password:string="";
  
    
}



