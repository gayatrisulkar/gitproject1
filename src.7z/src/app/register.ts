export interface Registerinfo {
    user_id:number;
    f_name:string;
    l_name:string;
    address:string;
    email_id:string;
    phone_no:number;
    password:string;
}