import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { RegisterService } from './employee.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { CreateRegisterComponent } from './create-register/create-register.component';
import { UpdateRegisterComponent } from './update-register/update-register.component';
import { RegisterDetailsComponent } from './register-details/register-details.component';
import { LoginComponent } from './ulogin/ulogin.component';
import { HomeComponent } from './home/home.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { ProductListComponent } from './product-list/product-list.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { OrderListComponent } from './order-list/order-list.component';
import { GallaryComponent } from './gallary/gallary.component';
import { MenuComponent } from './menu/menu.component';
import { ContactComponent } from './contact/contact.component';
import { HeaderComponent } from './header/header.component';
import { CreateOrderComponent } from './create-order/create-order.component';
import { AloginComponent } from './alogin/alogin.component';
import { AproductListComponent } from './aproduct-list/aproduct-list.component';
import { HproductListComponent } from './hproduct-list/hproduct-list.component';
import { AdminComponent } from './admin/admin.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterListComponent,
    CreateRegisterComponent,
    UpdateRegisterComponent,
    RegisterDetailsComponent,
    LoginComponent,
    HomeComponent,
    CreateProductComponent,
    ProductDetailsComponent,
    UpdateProductComponent,
    ProductListComponent,
    OrderDetailsComponent,
    OrderListComponent,
    HeaderComponent,
    GallaryComponent,
    MenuComponent,
    ContactComponent,
    CreateOrderComponent,
    AloginComponent,
    AproductListComponent,
    HproductListComponent,
    AdminComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [RegisterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
